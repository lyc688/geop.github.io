import { UploadedImageModel } from '@/common/model/upload.model'

export default interface UploadedImageListStateTypes {
  uploadedImageList: UploadedImageModel[]
}
