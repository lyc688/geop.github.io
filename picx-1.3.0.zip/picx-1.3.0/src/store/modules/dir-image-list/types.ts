export default interface DirImageListStateTypes {
  name: string
  dirImageList: any[]
}
