export default interface ToUploadImageStateTypes {
  curImgBase64Url: string
  curImgUuid: string
  list: any[]
  uploadedNumber: number
}
