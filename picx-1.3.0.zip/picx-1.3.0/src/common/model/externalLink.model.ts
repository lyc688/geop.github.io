export enum ExternalLinkType {
  gh = 'gh',
  md_gh = 'md_gh',
  cdn = 'cdn',
  md_cdn = 'md_cdn'
}
